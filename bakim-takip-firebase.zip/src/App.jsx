import { useState, useMemo, useEffect, useCallback, useRef } from "react";
import { db, ref, set, get, onValue } from "./firebase.js";

const INIT_KULLANICILAR = [
  { kullanici: "kahraman", sifre: "1234", ad: "Burhan Kahraman" },
  { kullanici: "sahan",    sifre: "1234", ad: "Yunus Şahan" },
  { kullanici: "turhan",   sifre: "1234", ad: "Arif Turhan" },
  { kullanici: "kilic",    sifre: "1234", ad: "Diyarcan Kılıç" },
];

const CIHAZ_TURLERI = ["Biyokimya", "Hormon", "ISE"];
const INITIAL_KURUMLAR = Array.from({ length: 15 }, (_, i) => ({ id: i + 1, ad: `Kurum ${i + 1}` }));
const STORAGE_KEY  = "bakim_app_data_v3";
const SIFRE_KEY    = "bakim_sifre_v1";

function gunFarki(t) {
  if (!t) return null;
  return Math.floor((new Date() - new Date(t)) / 86400000);
}
function fmt(t) {
  if (!t) return "—";
  return new Date(t).toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function Durum({ tarih, sm }) {
  const g = gunFarki(tarih);
  const b = sm ? "bsm" : "b";
  if (g === null) return <span className={`${b} bu`}>Bakım Yok</span>;
  if (g <= 30)    return <span className={`${b} bok`}>✓ {g}g</span>;
  if (g <= 90)    return <span className={`${b} bwarn`}>⚠ {g}g</span>;
  return              <span className={`${b} bdanger`}>✗ {g}g</span>;
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@300;400;500;600&family=Bebas+Neue&display=swap');
*{box-sizing:border-box;margin:0;padding:0;}
html,body{height:100%;background:#f0ede6;}
.app{min-height:100vh;background:#f0ede6;font-family:'IBM Plex Mono',monospace;color:#1a1a1a;}

/* LOGIN */
.login-wrap{min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f0ede6;position:relative;overflow:hidden;}
.login-bg{position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 39px,#d8d4cc 39px,#d8d4cc 40px),repeating-linear-gradient(90deg,transparent,transparent 39px,#d8d4cc 39px,#d8d4cc 40px);opacity:.4;}
.login-card{position:relative;background:#1a1a1a;color:#f0ede6;padding:48px 40px;width:100%;max-width:380px;border-radius:2px;}
.login-logo{font-family:'Bebas Neue',sans-serif;font-size:42px;letter-spacing:3px;margin-bottom:4px;color:#f0ede6;}
.login-logo span{color:#e85d26;}
.login-sub{font-size:11px;color:#666;letter-spacing:2px;text-transform:uppercase;margin-bottom:36px;}
.login-label{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#666;margin-bottom:6px;display:block;}
.login-input{width:100%;background:#2a2a2a;border:1px solid #333;color:#f0ede6;padding:12px 14px;font-family:inherit;font-size:13px;outline:none;border-radius:1px;margin-bottom:16px;transition:border-color .2s;}
.login-input:focus{border-color:#e85d26;}
.login-btn{width:100%;background:#e85d26;color:#fff;border:none;padding:14px;font-family:'Bebas Neue',sans-serif;font-size:20px;letter-spacing:3px;cursor:pointer;border-radius:1px;margin-top:8px;transition:background .2s;}
.login-btn:hover{background:#ff7040;}
.login-err{color:#ff6b6b;font-size:11px;margin-top:10px;text-align:center;letter-spacing:1px;}
.login-ok{color:#4ade80;font-size:11px;margin-top:10px;text-align:center;letter-spacing:1px;}

/* HEADER */
.hdr{background:#1a1a1a;padding:0 24px;display:flex;align-items:center;justify-content:space-between;height:52px;position:sticky;top:0;z-index:100;}
.logo{font-family:'Bebas Neue',sans-serif;font-size:24px;letter-spacing:3px;color:#f0ede6;cursor:pointer;transition:color .2s;}
.logo:hover{color:#e85d26;}
.logo span{color:#e85d26;}
.kurum-select-main{width:100%;background:#1a1a1a;border:1px solid #333;color:#f0ede6;padding:14px 16px;font-family:'IBM Plex Mono',monospace;font-size:13px;outline:none;border-radius:1px;cursor:pointer;transition:border-color .2s;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23e85d26' stroke-width='2' fill='none'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 16px center;}
.kurum-select-main:focus{border-color:#e85d26;}
.kurum-select-main option{background:#1a1a1a;color:#f0ede6;}
.hdr-right{display:flex;align-items:center;gap:10px;}
.hdr-user{font-size:11px;color:#666;letter-spacing:1px;white-space:nowrap;}
.hdr-user span{color:#e85d26;}
.hdr-btn{background:none;border:1px solid #333;color:#666;padding:5px 10px;font-family:inherit;font-size:10px;letter-spacing:1px;cursor:pointer;border-radius:1px;transition:all .2s;white-space:nowrap;}
.hdr-btn:hover{border-color:#e85d26;color:#e85d26;}
.sync-dot{width:7px;height:7px;border-radius:50%;background:#4ade80;display:inline-block;margin-right:4px;}
.sync-dot.syncing{background:#fbbf24;animation:pulse 1s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

/* LAYOUT */
.layout{display:grid;grid-template-columns:220px 1fr;min-height:calc(100vh - 52px);}
.sidebar{background:#1a1a1a;padding:20px 0;overflow-y:auto;}
.sb-title{font-size:9px;letter-spacing:3px;text-transform:uppercase;color:#444;padding:0 16px 12px;}
.ki{display:flex;align-items:center;justify-content:space-between;padding:8px 16px;cursor:pointer;border-left:3px solid transparent;transition:all .15s;}
.ki:hover{background:#252525;}
.ki.active{background:#252525;border-left-color:#e85d26;}
.ki-name{font-size:11px;color:#aaa;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ki.active .ki-name{color:#e85d26;}
.ki-meta{font-size:9px;color:#444;margin-top:2px;}
.ki-edit{background:none;border:none;color:#333;cursor:pointer;font-size:12px;padding:2px 5px;transition:color .2s;line-height:1;flex-shrink:0;}
.ki-edit:hover{color:#e85d26;}
.sb-home{display:flex;align-items:center;gap:8px;padding:10px 16px 18px;cursor:pointer;border-bottom:1px solid #222;margin-bottom:8px;}
.sb-home-txt{font-size:10px;letter-spacing:1px;color:#555;text-transform:uppercase;}
.sb-home:hover .sb-home-txt{color:#e85d26;}

/* MAIN */
.main{padding:24px;overflow-y:auto;background:#f0ede6;}

/* PAGE HEADER */
.page-hdr{display:flex;align-items:center;gap:10px;margin-bottom:20px;}
.home-btn{background:#1a1a1a;border:none;color:#f0ede6;padding:7px 14px;font-family:'Bebas Neue',sans-serif;font-size:14px;letter-spacing:1px;cursor:pointer;border-radius:1px;display:flex;align-items:center;gap:6px;transition:background .2s;white-space:nowrap;}
.home-btn:hover{background:#e85d26;}
.bc{display:flex;align-items:center;gap:6px;font-size:11px;color:#bbb;}
.bcl{color:#e85d26;cursor:pointer;background:none;border:none;font-family:inherit;font-size:11px;padding:0;}
.bcl:hover{text-decoration:underline;}

/* STATS */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:22px;}
.sc{background:#1a1a1a;padding:16px;border-radius:1px;}
.sc-l{font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#555;margin-bottom:6px;}
.sc-v{font-family:'Bebas Neue',sans-serif;font-size:34px;line-height:1;}
.sc.t .sc-v{color:#f0ede6;}.sc.ok .sc-v{color:#4ade80;}.sc.wn .sc-v{color:#fbbf24;}.sc.cr .sc-v{color:#f87171;}

/* TOOLBAR */
.tb{display:flex;gap:10px;margin-bottom:16px;align-items:center;flex-wrap:wrap;}
.inp{background:#fff;border:1px solid #d0ccc4;color:#1a1a1a;padding:9px 14px;font-family:inherit;font-size:12px;outline:none;border-radius:1px;transition:border-color .2s;}
.inp:focus{border-color:#e85d26;}
.inp::placeholder{color:#aaa;}
.inp-g{flex:1;min-width:160px;}

/* BUTTONS */
.btn{background:#e85d26;color:#fff;border:none;padding:9px 20px;font-family:'Bebas Neue',sans-serif;font-size:16px;letter-spacing:1px;cursor:pointer;border-radius:1px;transition:all .2s;white-space:nowrap;}
.btn:hover{background:#ff7040;transform:translateY(-1px);}
.btn-s{background:#fff;border:1px solid #d0ccc4;color:#1a1a1a;font-family:'IBM Plex Mono',monospace;font-size:11px;padding:8px 14px;cursor:pointer;border-radius:1px;transition:all .2s;}
.btn-s:hover{border-color:#e85d26;color:#e85d26;}
.btn-sm{padding:5px 14px;font-size:13px;}
.btn-s-sm{padding:4px 10px;font-size:10px;}

/* TABLE */
.tw{background:#fff;border:1px solid #d0ccc4;border-radius:1px;overflow:hidden;}
table{width:100%;border-collapse:collapse;}
th{background:#f8f5ef;border-bottom:1px solid #d0ccc4;padding:10px 14px;text-align:left;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#888;font-weight:500;}
td{padding:12px 14px;font-size:12px;border-bottom:1px solid #eee;vertical-align:middle;}
tr:last-child td{border-bottom:none;}
tr:hover td{background:#faf8f4;}

/* BADGES */
.b,.bsm{display:inline-block;padding:3px 9px;border-radius:0;font-size:11px;font-weight:500;letter-spacing:.5px;}
.bsm{padding:2px 7px;font-size:10px;}
.bok{background:#dcfce7;color:#16a34a;border:1px solid #bbf7d0;}
.bwarn{background:#fef9c3;color:#a16207;border:1px solid #fef08a;}
.bdanger{background:#fee2e2;color:#dc2626;border:1px solid #fecaca;}
.bu{background:#f3f4f6;color:#6b7280;border:1px solid #e5e7eb;}
.ktag{font-size:10px;color:#888;background:#f3f0ea;padding:2px 7px;border-radius:1px;}

/* KURUM DETAY */
.kd-hdr{margin-bottom:20px;}
.kd-ust{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;flex-wrap:wrap;}
.kd-title{font-family:'Bebas Neue',sans-serif;font-size:30px;letter-spacing:2px;color:#1a1a1a;}
.kd-meta{font-size:11px;color:#999;margin-top:4px;}
.kd-acts{display:flex;gap:8px;flex-wrap:wrap;align-items:flex-start;margin-top:6px;}

/* CİHAZ KARTLARI */
.cg{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px;}
.cc{background:#fff;border:1px solid #d0ccc4;padding:14px;cursor:pointer;transition:all .2s;border-radius:1px;border-top:3px solid transparent;}
.cc:hover{border-top-color:#e85d26;transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.08);}
.cc-ad{font-size:13px;font-weight:600;margin-bottom:6px;}
.cc-sb{font-size:10px;color:#aaa;margin-top:10px;}
.cc-alt{display:flex;align-items:center;justify-content:space-between;margin-top:4px;}

/* CİHAZ DETAY */
.dh{display:flex;align-items:flex-start;justify-content:space-between;margin-bottom:20px;gap:12px;flex-wrap:wrap;}
.d-title{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:2px;}
.d-meta{font-size:11px;color:#999;margin-top:4px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}

/* BAKIM */
.bl{display:flex;flex-direction:column;gap:10px;}
.bi{background:#fff;border:1px solid #d0ccc4;padding:14px 18px;display:flex;align-items:flex-start;gap:14px;border-radius:1px;border-left:3px solid #e85d26;}
.b-box{text-align:center;min-width:46px;}
.b-gun{font-family:'Bebas Neue',sans-serif;font-size:28px;color:#e85d26;line-height:1;}
.b-ay{font-size:9px;color:#aaa;text-transform:uppercase;letter-spacing:1px;}
.b-det{flex:1;}
.b-who{font-size:12px;font-weight:500;margin-bottom:3px;}
.b-note{font-size:11px;color:#888;}
.b-editor{font-size:10px;color:#bbb;margin-top:4px;}

/* MODAL */
.ov{position:fixed;inset:0;background:rgba(0,0,0,.6);display:flex;align-items:center;justify-content:center;z-index:200;padding:20px;}
.modal{background:#fff;padding:28px;width:100%;max-width:460px;animation:su .2s ease;border-radius:1px;border-top:3px solid #e85d26;}
@keyframes su{from{transform:translateY(14px);opacity:0}to{transform:translateY(0);opacity:1}}
.m-title{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:2px;margin-bottom:20px;color:#1a1a1a;}
.fg{margin-bottom:14px;}
label{display:block;font-size:9px;letter-spacing:2px;text-transform:uppercase;color:#999;margin-bottom:5px;}
.fi{width:100%;background:#faf8f4;border:1px solid #d0ccc4;color:#1a1a1a;padding:10px 12px;font-family:inherit;font-size:12px;outline:none;border-radius:1px;transition:border-color .2s;}
.fi:focus{border-color:#e85d26;}
.fi:disabled{opacity:.5;cursor:not-allowed;background:#f0ede6;}
textarea.fi{min-height:70px;resize:vertical;}
.m-acts{display:flex;gap:8px;margin-top:20px;justify-content:flex-end;}
.m-err{color:#dc2626;font-size:11px;margin-top:8px;letter-spacing:.5px;}
.m-ok{color:#16a34a;font-size:11px;margin-top:8px;letter-spacing:.5px;}

/* TEKNİK BİLGİ TAM EKRAN */
.tb-overlay{position:fixed;inset:0;background:#f0ede6;z-index:150;overflow-y:auto;}
.tb-page{max-width:1100px;margin:0 auto;padding:28px;}
.tb-hdr{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:8px;flex-wrap:wrap;}
.tb-hdr-left{display:flex;align-items:center;gap:0;}
.tb-isim{font-family:'Bebas Neue',sans-serif;font-size:26px;letter-spacing:2px;color:#1a1a1a;}
.tb-isim-input{font-family:'Bebas Neue',sans-serif;font-size:22px;letter-spacing:2px;background:#fff;border:1px solid #e85d26;color:#1a1a1a;padding:4px 10px;outline:none;border-radius:1px;width:220px;}
.tb-edit-btn{background:#1a1a1a;border:none;color:#aaa;font-family:'IBM Plex Mono',monospace;font-size:10px;letter-spacing:1px;padding:5px 10px;cursor:pointer;border-radius:1px;transition:all .2s;}
.tb-edit-btn:hover{background:#e85d26;color:#fff;}
.tb-not-sec{background:#1a1a1a;border:1px solid #333;color:#f0ede6;padding:8px 12px;font-family:'IBM Plex Mono',monospace;font-size:11px;outline:none;border-radius:1px;cursor:pointer;}
.tb-not-sec:focus{border-color:#e85d26;}

/* EXCEL TABLO */
.excel-wrap{overflow-x:auto;border:2px solid #1a1a1a;border-radius:1px;background:#fff;}
.excel-tbl{width:100%;border-collapse:collapse;min-width:400px;}
.excel-th{background:#1a1a1a;padding:0;border-right:1px solid #333;min-width:120px;}
.excel-th:last-of-type{border-right:none;}
.excel-th-inner{display:flex;align-items:center;gap:4px;padding:2px 4px;}
.excel-th-input{background:transparent;border:none;color:#f0ede6;font-family:'IBM Plex Mono',monospace;font-size:11px;font-weight:600;letter-spacing:1px;text-transform:uppercase;padding:8px 6px;outline:none;width:100%;cursor:text;}
.excel-th-input:focus{background:rgba(232,93,38,.15);}
.excel-del-col{background:none;border:none;color:#555;cursor:pointer;font-size:14px;padding:2px 4px;line-height:1;transition:color .15s;flex-shrink:0;}
.excel-del-col:hover{color:#f87171;}
.excel-th-action{background:#1a1a1a;padding:4px;text-align:center;width:36px;border-left:1px solid #333;}
.excel-add-col{background:none;border:1px solid #444;color:#888;width:26px;height:26px;border-radius:1px;cursor:pointer;font-size:16px;line-height:1;display:flex;align-items:center;justify-content:center;margin:0 auto;transition:all .15s;}
.excel-add-col:hover{border-color:#e85d26;color:#e85d26;}
.excel-tr-even td{background:#fff;}
.excel-tr-odd td{background:#faf8f4;}
.excel-td{padding:0;border-right:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb;}
.excel-cell{width:100%;background:transparent;border:none;color:#1a1a1a;font-family:'IBM Plex Mono',monospace;font-size:12px;padding:9px 10px;outline:none;transition:background .1s;}
.excel-cell:focus{background:rgba(232,93,38,.06);}
.excel-td-action{padding:4px;text-align:center;width:36px;border-bottom:1px solid #e5e7eb;background:#faf8f4;}
.excel-del-row{background:none;border:none;cursor:pointer;font-size:13px;padding:2px;opacity:.4;transition:opacity .15s;}
.excel-del-row:hover{opacity:1;}
.excel-add-row{display:flex;align-items:center;gap:6px;margin-top:8px;background:#1a1a1a;border:none;color:#f0ede6;font-family:'IBM Plex Mono',monospace;font-size:11px;letter-spacing:1px;padding:9px 16px;cursor:pointer;border-radius:1px;transition:background .2s;}
.excel-add-row:hover{background:#e85d26;}
.empty{text-align:center;padding:48px 20px;color:#ccc;}
.empty .ico{font-size:36px;margin-bottom:10px;}
.empty p{font-size:12px;}
.loading{display:flex;align-items:center;justify-content:center;height:200px;font-size:12px;color:#aaa;letter-spacing:2px;}

@media(max-width:900px){
  .layout{grid-template-columns:1fr;}
  .sidebar{display:none;}
  .stats{grid-template-columns:repeat(2,1fr);}
  .hdr-mid{display:flex;}
}
@media(max-width:600px){
  .main{padding:14px;}
  .hdr-user{display:none;}
  .kurum-select{min-width:120px;font-size:11px;padding:5px 8px;}
}
`;

export default function App() {
  // Şifreler storage'da saklanır
  const [kullanicilar, setKullanicilar] = useState(INIT_KULLANICILAR);
  const [aktifKullanici, setAktifKullanici] = useState(null);
  const [loginForm, setLoginForm]   = useState({ k: "", s: "" });
  const [loginErr, setLoginErr]     = useState("");

  const [kurumlar, setKurumlar]   = useState(INITIAL_KURUMLAR);
  const [cihazlar, setCihazlar]   = useState([]);
  const [bakimlar, setBakimlar]   = useState([]);
  const [yuklendi, setYuklendi]   = useState(false);
  const [syncing, setSyncing]     = useState(false);

  const [ekran, setEkran]               = useState("kurumlar");
  const [seciliKurumId, setSeciliKurumId] = useState(null);
  const [seciliCihazId, setSeciliCihazId] = useState(null);
  const [arama, setArama]               = useState("");

  const [modal, setModal]         = useState(null); // "cihazEkle"|"bakimEkle"|"isim"|"sifre"
  const [isimModal, setIsimModal] = useState(null);
  const [yeniIsim, setYeniIsim]   = useState("");
  const [cihazForm, setCihazForm] = useState({ ad: CIHAZ_TURLERI[0], seri: "" });
  const [bakimForm, setBakimForm] = useState({ tarih: new Date().toISOString().split("T")[0], notlar: "" });

  // Şifre değiştirme formu
  const [sifreForm, setSifreForm] = useState({ eski: "", yeni: "", tekrar: "" });
  const [sifreErr, setSifreErr]   = useState("");
  const [sifreOk, setSifreOk]     = useState("");

  // Yedek parça tabloları (5 adet, her biri satır listesi + sütun başlıkları)
  const DEFAULT_SUTUNLAR = ["Parça Adı", "Miktar", "Açıklama"];
  const [yedekTablolar, setYedekTablolar] = useState(
    Array.from({length:5}, (_,i) => ({
      id: i+1,
      isim: `Not ${i+1}`,
      sutunlar: [...DEFAULT_SUTUNLAR],
      satirlar: []
    }))
  );
  const [seciliYedekNo, setSeciliYedekNo] = useState("");
  const [teknikBilgiEkran, setTeknikBilgiEkran] = useState(false); // ayrı sayfa
  const [notIsmiDuzenle, setNotIsmiDuzenle] = useState(null); // {id, isim}

  // Veri yükleme - Firebase Realtime Database
  const yukleVeri = useCallback(async () => {
    try {
      const snap = await get(ref(db, "bakimApp"));
      if (snap.exists()) {
        const d = snap.val();
        if (d.kurumlar) setKurumlar(d.kurumlar);
        if (d.cihazlar) setCihazlar(d.cihazlar);
        if (d.bakimlar) setBakimlar(d.bakimlar);
        if (d.yedekTablolar) setYedekTablolar(d.yedekTablolar.map((t,i) => ({
          isim: `Not ${i+1}`, ...t
        })));
      }
    } catch(e) { console.error("Veri yükleme hatası:", e); }
    // Şifreleri yükle
    try {
      const sSnap = await get(ref(db, "bakimSifreler"));
      if (sSnap.exists()) setKullanicilar(sSnap.val());
    } catch(e) {}
    setYuklendi(true);
  }, []);

  const kaydetVeri = useCallback(async (k, c, b, yt) => {
    setSyncing(true);
    try {
      await set(ref(db, "bakimApp"), { kurumlar: k, cihazlar: c, bakimlar: b, yedekTablolar: yt });
    } catch(e) { console.error("Kayıt hatası:", e); }
    setTimeout(() => setSyncing(false), 600);
  }, []);

  const kaydetSifreler = useCallback(async (liste) => {
    try { await set(ref(db, "bakimSifreler"), liste); }
    catch(e) {}
  }, []);

  // Firebase realtime listener - değişiklikleri anlık al
  useEffect(() => {
    const unsubscribe = onValue(ref(db, "bakimApp"), (snap) => {
      if (snap.exists() && yuklendi) {
        const d = snap.val();
        if (d.kurumlar) setKurumlar(d.kurumlar);
        if (d.cihazlar) setCihazlar(d.cihazlar);
        if (d.bakimlar) setBakimlar(d.bakimlar);
        if (d.yedekTablolar) setYedekTablolar(prev =>
          d.yedekTablolar.map((t,i) => ({ isim: prev[i]?.isim || `Not ${i+1}`, ...t }))
        );
      }
    });
    return () => unsubscribe();
  }, [yuklendi]);

  useEffect(() => { yukleVeri(); }, []);

  function login() {
    const u = kullanicilar.find(x => x.kullanici === loginForm.k.trim().toLowerCase() && x.sifre === loginForm.s);
    if (u) { setAktifKullanici(u); setLoginErr(""); }
    else setLoginErr("Kullanıcı adı veya şifre hatalı.");
  }

  const seciliKurum = kurumlar.find(k => k.id === seciliKurumId);
  const seciliCihaz = cihazlar.find(c => c.id === seciliCihazId);

  const sonBakimlar = useMemo(() => {
    const m = {};
    bakimlar.forEach(b => {
      if (!m[b.cihazId] || new Date(b.tarih) > new Date(m[b.cihazId].tarih)) m[b.cihazId] = b;
    });
    return m;
  }, [bakimlar]);

  function ist(kurumId) {
    const l = cihazlar.filter(c => c.kurumId === kurumId);
    return {
      toplam: l.length,
      ok:     l.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g !== null && g <= 30; }).length,
      warn:   l.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g !== null && g > 30 && g <= 90; }).length,
      kritik: l.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g === null || g > 90; }).length,
    };
  }

  const genelIst = useMemo(() => ({
    toplam: cihazlar.length,
    ok:     cihazlar.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g !== null && g <= 30; }).length,
    warn:   cihazlar.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g !== null && g > 30 && g <= 90; }).length,
    kritik: cihazlar.filter(c => { const g = gunFarki(sonBakimlar[c.id]?.tarih); return g === null || g > 90; }).length,
  }), [cihazlar, sonBakimlar]);

  function goGenel()   { setEkran("kurumlar"); setSeciliKurumId(null); setSeciliCihazId(null); }
  function goKurum(id) { setSeciliKurumId(id); setEkran("kurumDetay"); setArama(""); setSeciliCihazId(null); }
  function goCihaz(id) { setSeciliCihazId(id); setEkran("cihazDetay"); }

  async function isimKaydet() {
    if (!yeniIsim.trim() || !isimModal) return;
    const yeni = kurumlar.map(k => k.id === isimModal.id ? { ...k, ad: yeniIsim.trim() } : k);
    setKurumlar(yeni);
    await kaydetVeri(yeni, cihazlar, bakimlar, yedekTablolar);
    setIsimModal(null); setModal(null);
  }

  async function cihazEkle() {
    if (!cihazForm.ad.trim() || !seciliKurumId) return;
    const yeni = [...cihazlar, { id: Date.now(), kurumId: seciliKurumId, ad: cihazForm.ad, seri: cihazForm.seri, ekleyen: aktifKullanici.ad }];
    setCihazlar(yeni);
    await kaydetVeri(kurumlar, yeni, bakimlar, yedekTablolar);
    setCihazForm({ ad: CIHAZ_TURLERI[0], seri: "" });
    setModal(null);
  }

  async function bakimEkle() {
    if (!seciliCihazId || !bakimForm.tarih) return;
    const yeni = [...bakimlar, { id: Date.now(), cihazId: seciliCihazId, tarih: bakimForm.tarih, yapan: aktifKullanici.ad, notlar: bakimForm.notlar, ekleyen: aktifKullanici.ad }];
    setBakimlar(yeni);
    await kaydetVeri(kurumlar, cihazlar, yeni, yedekTablolar);
    setBakimForm({ tarih: new Date().toISOString().split("T")[0], notlar: "" });
    setModal(null);
  }

  async function yedekTablo_satirEkle(tabloId) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t, satirlar: [...t.satirlar, { id: Date.now(), hücreler: Array(t.sutunlar.length).fill("") }] }
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_satirSil(tabloId, satirId) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t, satirlar: t.satirlar.filter(s => s.id !== satirId) }
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_hucreGuncelle(tabloId, satirId, kolIdx, deger) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t, satirlar: t.satirlar.map(s => s.id === satirId
          ? { ...s, hücreler: s.hücreler.map((h, i) => i === kolIdx ? deger : h) }
          : s
        )}
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_sutunGuncelle(tabloId, kolIdx, deger) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t, sutunlar: t.sutunlar.map((s, i) => i === kolIdx ? deger : s) }
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_sutunEkle(tabloId) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t,
          sutunlar: [...t.sutunlar, "Sütun"],
          satirlar: t.satirlar.map(s => ({ ...s, hücreler: [...s.hücreler, ""] }))
        }
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_sutunSil(tabloId, kolIdx) {
    const yeni = yedekTablolar.map(t => t.id === tabloId
      ? { ...t,
          sutunlar: t.sutunlar.filter((_, i) => i !== kolIdx),
          satirlar: t.satirlar.map(s => ({ ...s, hücreler: s.hücreler.filter((_, i) => i !== kolIdx) }))
        }
      : t
    );
    setYedekTablolar(yeni);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function yedekTablo_isimGuncelle(tabloId, yeniIsimDeger) {
    if (!yeniIsimDeger || !yeniIsimDeger.trim()) return;
    const yeni = yedekTablolar.map(t => t.id === tabloId ? { ...t, isim: yeniIsimDeger.trim() } : t);
    setYedekTablolar(yeni);
    setNotIsmiDuzenle(null);
    await kaydetVeri(kurumlar, cihazlar, bakimlar, yeni);
  }

  async function sifreDegistir() {
    setSifreErr(""); setSifreOk("");
    if (!sifreForm.eski) { setSifreErr("Mevcut şifrenizi girin."); return; }
    if (aktifKullanici.sifre !== sifreForm.eski) { setSifreErr("Mevcut şifre hatalı."); return; }
    if (sifreForm.yeni.length < 4) { setSifreErr("Yeni şifre en az 4 karakter olmalı."); return; }
    if (sifreForm.yeni !== sifreForm.tekrar) { setSifreErr("Şifreler eşleşmiyor."); return; }
    const guncellenmis = kullanicilar.map(u =>
      u.kullanici === aktifKullanici.kullanici ? { ...u, sifre: sifreForm.yeni } : u
    );
    setKullanicilar(guncellenmis);
    setAktifKullanici(prev => ({ ...prev, sifre: sifreForm.yeni }));
    await kaydetSifreler(guncellenmis);
    setSifreOk("Şifre başarıyla değiştirildi!");
    setSifreForm({ eski: "", yeni: "", tekrar: "" });
    setTimeout(() => { setSifreOk(""); setModal(null); }, 1500);
  }

  const kurumCihazlari = useMemo(() => {
    if (!seciliKurumId) return [];
    return cihazlar.filter(c =>
      c.kurumId === seciliKurumId &&
      (arama === "" || c.ad.toLowerCase().includes(arama.toLowerCase()) || (c.seri||"").toLowerCase().includes(arama.toLowerCase()))
    );
  }, [cihazlar, seciliKurumId, arama]);

  const cihazBakimlari = useMemo(() =>
    seciliCihazId ? bakimlar.filter(b => b.cihazId === seciliCihazId).sort((a,b) => new Date(b.tarih)-new Date(a.tarih)) : [],
    [bakimlar, seciliCihazId]
  );

  // LOGIN
  if (!aktifKullanici) return (
    <div className="app">
      <style>{CSS}</style>
      <div className="login-wrap">
        <div className="login-bg" />
        <div className="login-card">
          <div className="login-logo">BAKIM<span>.</span>TAKİP</div>
          <div className="login-sub">Cihaz Bakım Yönetim Sistemi</div>
          <label className="login-label">Kullanıcı Adı</label>
          <input className="login-input" placeholder="kullanıcı adı" value={loginForm.k}
            onChange={e => setLoginForm({...loginForm, k: e.target.value})}
            onKeyDown={e => e.key==="Enter" && login()} />
          <label className="login-label">Şifre</label>
          <input className="login-input" type="password" placeholder="••••" value={loginForm.s}
            onChange={e => setLoginForm({...loginForm, s: e.target.value})}
            onKeyDown={e => e.key==="Enter" && login()} />
          <button className="login-btn" onClick={login}>GİRİŞ YAP</button>
          {loginErr && <div className="login-err">{loginErr}</div>}
        </div>
      </div>
    </div>
  );

  if (!yuklendi) return (
    <div className="app"><style>{CSS}</style>
      <div className="loading">VERİLER YÜKLENİYOR...</div>
    </div>
  );

  return (
    <div className="app">
      <style>{CSS}</style>

      {/* HEADER */}
      <div className="hdr">
        <div className="logo" onClick={goGenel}>BAKIM<span>.</span>TAKİP</div>

        <div className="hdr-right">
          <span style={{fontSize:10,color:"#555",letterSpacing:1}}>
            <span className={`sync-dot ${syncing?"syncing":""}`}/>
            {syncing ? "KAYDEDİLİYOR" : "CANLI"}
          </span>
          <span className="hdr-user">👤 <span>{aktifKullanici.ad}</span></span>
          <button className="hdr-btn" onClick={() => { setSifreForm({eski:"",yeni:"",tekrar:""}); setSifreErr(""); setSifreOk(""); setModal("sifre"); }}>ŞİFRE</button>
          <button className="hdr-btn" onClick={() => setAktifKullanici(null)}>ÇIKIŞ</button>
        </div>
      </div>

      <div className="layout">
        {/* SIDEBAR */}
        <div className="sidebar">
          <div className="sb-home" onClick={goGenel}>
            <span style={{fontSize:16}}>🏠</span>
            <span className="sb-home-txt">Ana Sayfa</span>
          </div>
          <div className="sb-title">Kurumlar</div>
          {kurumlar.map(k => {
            const i = ist(k.id);
            return (
              <div key={k.id} className={`ki ${seciliKurumId===k.id?"active":""}`} onClick={() => goKurum(k.id)}>
                <div style={{flex:1,minWidth:0}}>
                  <div className="ki-name">{k.ad}</div>
                  <div className="ki-meta">
                    {i.toplam} cihaz
                    {i.kritik > 0 && <span style={{color:"#f87171",marginLeft:5}}>• {i.kritik} kritik</span>}
                    {i.warn > 0 && i.kritik===0 && <span style={{color:"#fbbf24",marginLeft:5}}>• {i.warn} uyarı</span>}
                  </div>
                </div>
                <button className="ki-edit" title="İsim değiştir"
                  onClick={e => { e.stopPropagation(); setIsimModal(k); setYeniIsim(k.ad); setModal("isim"); }}>✎</button>
              </div>
            );
          })}
        </div>

        <div className="main">

          {/* Her sayfada ANA SAYFA butonu */}
          {ekran !== "kurumlar" && (
            <div className="page-hdr">
              <button className="home-btn" onClick={goGenel}>🏠 ANA SAYFA</button>
              <div className="bc">
                <span>›</span>
                {ekran === "kurumDetay" && seciliKurum && (
                  <span style={{color:"#1a1a1a"}}>{seciliKurum.ad}</span>
                )}
                {ekran === "cihazDetay" && seciliCihaz && (
                  <>
                    <button className="bcl" onClick={() => goKurum(seciliCihaz.kurumId)}>
                      {kurumlar.find(k=>k.id===seciliCihaz.kurumId)?.ad}
                    </button>
                    <span>›</span>
                    <span style={{color:"#1a1a1a"}}>{seciliCihaz.ad}</span>
                  </>
                )}
              </div>
            </div>
          )}

          {/* GENEL BAKIŞ */}
          {ekran === "kurumlar" && (
            <>
              <div className="stats">
                <div className="sc t"><div className="sc-l">Toplam Cihaz</div><div className="sc-v">{genelIst.toplam}</div></div>
                <div className="sc ok"><div className="sc-l">Güncel ≤30g</div><div className="sc-v">{genelIst.ok}</div></div>
                <div className="sc wn"><div className="sc-l">Uyarı 31-90g</div><div className="sc-v">{genelIst.warn}</div></div>
                <div className="sc cr"><div className="sc-l">Kritik/Bakımsız</div><div className="sc-v">{genelIst.kritik}</div></div>
              </div>
              <div style={{marginTop:8}}>
                <div style={{fontSize:9,letterSpacing:2,textTransform:"uppercase",color:"#999",marginBottom:8}}>Kurum Seçin</div>
                <select className="kurum-select-main"
                  value={seciliKurumId ?? ""}
                  onChange={e => {
                    const val = e.target.value;
                    if (val !== "") goKurum(Number(val));
                  }}>
                  <option value="">— Kurum Seçiniz —</option>
                  {kurumlar.map(k => (
                    <option key={k.id} value={k.id}>{k.ad}</option>
                  ))}
                </select>
              </div>

              {/* TEKNİK BİLGİ */}
              <div style={{marginTop:20}}>
                <div style={{fontSize:9,letterSpacing:2,textTransform:"uppercase",color:"#999",marginBottom:8}}>Teknik Bilgi</div>
                <select className="kurum-select-main" value={seciliYedekNo}
                  onChange={e => {
                    setSeciliYedekNo(e.target.value);
                    if (e.target.value !== "") setTeknikBilgiEkran(true);
                  }}>
                  <option value="">— Not Seçiniz —</option>
                  {yedekTablolar.map(t => (
                    <option key={t.id} value={t.id}>{t.isim}</option>
                  ))}
                </select>
              </div>
            </>
          )}

          {/* KURUM DETAY */}
          {ekran === "kurumDetay" && seciliKurum && (
            <>
              <div className="kd-hdr">
                <div className="kd-ust">
                  <div>
                    <div className="kd-title">{seciliKurum.ad}</div>
                    <div className="kd-meta">
                      {ist(seciliKurum.id).toplam} cihaz
                      {ist(seciliKurum.id).ok > 0 && <span style={{color:"#16a34a"}}> · {ist(seciliKurum.id).ok} güncel</span>}
                      {ist(seciliKurum.id).warn > 0 && <span style={{color:"#a16207"}}> · {ist(seciliKurum.id).warn} uyarı</span>}
                      {ist(seciliKurum.id).kritik > 0 && <span style={{color:"#dc2626"}}> · {ist(seciliKurum.id).kritik} kritik</span>}
                    </div>
                  </div>
                  <div className="kd-acts">
                    <button className="btn-s btn-s-sm" onClick={() => { setIsimModal(seciliKurum); setYeniIsim(seciliKurum.ad); setModal("isim"); }}>✎ İsim Değiştir</button>
                    <button className="btn btn-sm" onClick={() => setModal("cihazEkle")}>+ CİHAZ EKLE</button>
                  </div>
                </div>
              </div>
              <div className="tb">
                <input className="inp inp-g" placeholder="Cihaz ara..." value={arama} onChange={e => setArama(e.target.value)} />
              </div>
              {kurumCihazlari.length === 0 ? (
                <div className="empty">
                  <div className="ico">🏥</div>
                  <p>{cihazlar.filter(c=>c.kurumId===seciliKurumId).length===0 ? "Henüz cihaz eklenmedi." : "Sonuç bulunamadı."}</p>
                </div>
              ) : (
                <div className="cg">
                  {kurumCihazlari.map(c => {
                    const sb = sonBakimlar[c.id];
                    return (
                      <div key={c.id} className="cc" onClick={() => goCihaz(c.id)}>
                        <div className="cc-ad">{c.ad}</div>
                        {c.seri && <div style={{fontSize:10,color:"#bbb"}}>S/N: {c.seri}</div>}
                        <div className="cc-sb">Son Bakım</div>
                        <div className="cc-alt">
                          <div style={{fontSize:12,fontWeight:500}}>{fmt(sb?.tarih)}</div>
                          <Durum tarih={sb?.tarih} sm />
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}

          {/* CİHAZ DETAY */}
          {ekran === "cihazDetay" && seciliCihaz && (
            <>
              <div className="dh">
                <div>
                  <div className="d-title">{seciliCihaz.ad}</div>
                  <div className="d-meta">
                    <span className="ktag">{kurumlar.find(k=>k.id===seciliCihaz.kurumId)?.ad}</span>
                    {seciliCihaz.seri && <span style={{color:"#bbb"}}>S/N: {seciliCihaz.seri}</span>}
                  </div>
                </div>
                <button className="btn btn-sm" onClick={() => { setBakimForm({ tarih: new Date().toISOString().split("T")[0], notlar: "" }); setModal("bakimEkle"); }}>+ BAKIM EKLE</button>
              </div>
              {cihazBakimlari.length === 0 ? (
                <div className="empty"><div className="ico">🔧</div><p>Henüz bakım kaydı yok.</p></div>
              ) : (
                <div className="bl">
                  {cihazBakimlari.map(b => {
                    const d = new Date(b.tarih);
                    return (
                      <div key={b.id} className="bi">
                        <div className="b-box">
                          <div className="b-gun">{d.getDate().toString().padStart(2,"0")}</div>
                          <div className="b-ay">{d.toLocaleDateString("tr-TR",{month:"short",year:"2-digit"})}</div>
                        </div>
                        <div className="b-det">
                          <div className="b-who">👤 {b.yapan}</div>
                          {b.notlar && <div className="b-note">{b.notlar}</div>}
                          <div className="b-editor">Ekleyen: {b.ekleyen}</div>
                        </div>
                        <Durum tarih={b.tarih} sm />
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* TEKNİK BİLGİ SAYFASI - TAM EKRAN OVERLAY */}
      {teknikBilgiEkran && seciliYedekNo !== "" && (() => {
        const tablo = yedekTablolar.find(t => t.id === Number(seciliYedekNo));
        if (!tablo) return null;
        return (
          <div className="tb-overlay">
            <div className="tb-page">
              {/* Sayfa Başlığı */}
              <div className="tb-hdr">
                <div className="tb-hdr-left">
                  <button className="home-btn" onClick={() => { setTeknikBilgiEkran(false); setSeciliYedekNo(""); }}>
                    ← GERİ
                  </button>
                  <div style={{marginLeft:16}}>
                    <div style={{fontSize:9,letterSpacing:2,textTransform:"uppercase",color:"#999"}}>Teknik Bilgi</div>
                    <div style={{display:"flex",alignItems:"center",gap:8,marginTop:4}}>
                      {notIsmiDuzenle?.id === tablo.id ? (
                        <>
                          <input className="tb-isim-input" autoFocus
                            value={notIsmiDuzenle.isim}
                            onChange={e => setNotIsmiDuzenle(prev => ({...prev, isim: e.target.value}))}
                            onKeyDown={e => {
                              if (e.key === "Enter") yedekTablo_isimGuncelle(tablo.id, notIsmiDuzenle.isim);
                              if (e.key === "Escape") setNotIsmiDuzenle(null);
                            }}
                          />
                          <button className="btn btn-sm" onClick={() => yedekTablo_isimGuncelle(tablo.id, notIsmiDuzenle.isim)}>KAYDET</button>
                          <button className="btn-s btn-s-sm" onClick={() => setNotIsmiDuzenle(null)}>İptal</button>
                        </>
                      ) : (
                        <>
                          <div className="tb-isim">{tablo.isim}</div>
                          <button className="tb-edit-btn" onClick={() => setNotIsmiDuzenle({id: tablo.id, isim: tablo.isim})}>✎ İsim Değiştir</button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div style={{display:"flex",gap:8,alignItems:"center"}}>
                  <select className="tb-not-sec"
                    value={seciliYedekNo}
                    onChange={e => { setSeciliYedekNo(e.target.value); setNotIsmiDuzenle(null); }}>
                    {yedekTablolar.map(t => (
                      <option key={t.id} value={t.id}>{t.isim}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Excel Tablo */}
              <div className="excel-wrap" style={{marginTop:16}}>
                <table className="excel-tbl">
                  <thead>
                    <tr>
                      {tablo.sutunlar.map((s, ci) => (
                        <th key={ci} className="excel-th">
                          <div className="excel-th-inner">
                            <input className="excel-th-input" value={s}
                              onChange={e => yedekTablo_sutunGuncelle(tablo.id, ci, e.target.value)} />
                            {tablo.sutunlar.length > 1 &&
                              <button className="excel-del-col" onClick={() => yedekTablo_sutunSil(tablo.id, ci)}>×</button>}
                          </div>
                        </th>
                      ))}
                      <th className="excel-th-action">
                        <button className="excel-add-col" onClick={() => yedekTablo_sutunEkle(tablo.id)}>+</button>
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {tablo.satirlar.map((satir, si) => (
                      <tr key={satir.id} className={si%2===0?"excel-tr-even":"excel-tr-odd"}>
                        {satir.hücreler.map((h, ci) => (
                          <td key={ci} className="excel-td">
                            <input className="excel-cell" value={h}
                              onChange={e => yedekTablo_hucreGuncelle(tablo.id, satir.id, ci, e.target.value)} />
                          </td>
                        ))}
                        <td className="excel-td-action">
                          <button className="excel-del-row" onClick={() => yedekTablo_satirSil(tablo.id, satir.id)}>🗑</button>
                        </td>
                      </tr>
                    ))}
                    {tablo.satirlar.length === 0 && (
                      <tr>
                        <td colSpan={tablo.sutunlar.length+1} style={{textAlign:"center",padding:"28px",color:"#aaa",fontSize:12}}>
                          Henüz satır yok — aşağıdan ekleyin
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
              <button className="excel-add-row" onClick={() => yedekTablo_satirEkle(tablo.id)}>
                + Satır Ekle
              </button>
            </div>
          </div>
        );
      })()}

      {/* MODAL: KURUM İSMİ */}
      {modal === "isim" && isimModal && (
        <div className="ov" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="m-title">KURUM İSMİ DEĞIŞTIR</div>
            <div className="fg">
              <label>Mevcut İsim</label>
              <div style={{fontSize:13,color:"#888",marginBottom:14,padding:"8px 12px",background:"#faf8f4",border:"1px solid #e5e7eb"}}>{isimModal.ad}</div>
              <label>Yeni İsim</label>
              <input className="fi" autoFocus value={yeniIsim}
                onChange={e => setYeniIsim(e.target.value)}
                onKeyDown={e => e.key==="Enter" && isimKaydet()} />
            </div>
            <div className="m-acts">
              <button className="btn-s" onClick={() => setModal(null)}>İptal</button>
              <button className="btn btn-sm" onClick={isimKaydet}>KAYDET</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CİHAZ EKLE */}
      {modal === "cihazEkle" && (
        <div className="ov" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="m-title">YENİ CİHAZ EKLE</div>
            <div style={{fontSize:11,color:"#999",marginBottom:18,padding:"8px 12px",background:"#faf8f4",border:"1px solid #eee"}}>
              Kurum: <strong style={{color:"#e85d26"}}>{seciliKurum?.ad}</strong>
            </div>
            <div className="fg">
              <label>Cihaz Türü</label>
              <select className="fi" value={cihazForm.ad} onChange={e => setCihazForm({...cihazForm, ad: e.target.value})}>
                {CIHAZ_TURLERI.map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div className="fg">
              <label>Seri No</label>
              <input className="fi" value={cihazForm.seri} onChange={e => setCihazForm({...cihazForm, seri: e.target.value})} />
            </div>
            <div className="m-acts">
              <button className="btn-s" onClick={() => setModal(null)}>İptal</button>
              <button className="btn btn-sm" onClick={cihazEkle}>KAYDET</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: BAKIM EKLE */}
      {modal === "bakimEkle" && seciliCihaz && (
        <div className="ov" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="m-title">BAKIM KAYDI EKLE</div>
            <div style={{fontSize:11,color:"#999",marginBottom:18,padding:"8px 12px",background:"#faf8f4",border:"1px solid #eee"}}>
              <strong>{seciliCihaz.ad}</strong> — {kurumlar.find(k=>k.id===seciliCihaz.kurumId)?.ad}
            </div>
            <div className="fg">
              <label>Bakım Tarihi</label>
              <input type="date" className="fi" value={bakimForm.tarih}
                onChange={e => setBakimForm({...bakimForm, tarih: e.target.value})} />
            </div>
            <div className="fg">
              <label>Teknisyen</label>
              <input className="fi" value={aktifKullanici.ad} disabled />
            </div>
            <div className="fg">
              <label>Notlar</label>
              <textarea className="fi" placeholder="Yapılan işlemler..." value={bakimForm.notlar}
                onChange={e => setBakimForm({...bakimForm, notlar: e.target.value})} />
            </div>
            <div className="m-acts">
              <button className="btn-s" onClick={() => setModal(null)}>İptal</button>
              <button className="btn btn-sm" onClick={bakimEkle}>KAYDET</button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ŞİFRE DEĞİŞTİR */}
      {modal === "sifre" && (
        <div className="ov" onClick={() => setModal(null)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="m-title">ŞİFRE DEĞİŞTİR</div>
            <div style={{fontSize:11,color:"#999",marginBottom:18,padding:"8px 12px",background:"#faf8f4",border:"1px solid #eee"}}>
              Kullanıcı: <strong style={{color:"#e85d26"}}>{aktifKullanici.ad}</strong>
            </div>
            <div className="fg">
              <label>Mevcut Şifre</label>
              <input type="password" className="fi" placeholder="••••" value={sifreForm.eski}
                onChange={e => setSifreForm({...sifreForm, eski: e.target.value})} />
            </div>
            <div className="fg">
              <label>Yeni Şifre</label>
              <input type="password" className="fi" placeholder="••••" value={sifreForm.yeni}
                onChange={e => setSifreForm({...sifreForm, yeni: e.target.value})} />
            </div>
            <div className="fg">
              <label>Yeni Şifre (Tekrar)</label>
              <input type="password" className="fi" placeholder="••••" value={sifreForm.tekrar}
                onChange={e => setSifreForm({...sifreForm, tekrar: e.target.value})}
                onKeyDown={e => e.key==="Enter" && sifreDegistir()} />
            </div>
            {sifreErr && <div className="m-err">⚠ {sifreErr}</div>}
            {sifreOk  && <div className="m-ok">✓ {sifreOk}</div>}
            <div className="m-acts">
              <button className="btn-s" onClick={() => setModal(null)}>İptal</button>
              <button className="btn btn-sm" onClick={sifreDegistir}>DEĞİŞTİR</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
